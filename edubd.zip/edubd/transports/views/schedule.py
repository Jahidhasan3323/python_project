from django.shortcuts import render
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import reverse
from django.contrib.auth.models import User
from ..models import Schedule,Stopage,ScheduleStopage,ScheduleMember
from ..form import ScheduleForm,ScheduleStopageForm, ScheduleMemberForm
from django.contrib import messages
# Create your views here.


def index(request):
    schedules=Schedule.objects.all().order_by('-id')
    contex = {'schedules':schedules}
    return render(request, 'schedule/index.html',contex)

def create(request):
    form = ScheduleForm()
    if request.method=='POST':
        schedule=request.POST
        form = ScheduleForm(request.POST)
        if form.is_valid():
           schedule=form.save()
           messages.success(request,'Data store successfull',extra_tags='success')
           return redirect('/schedule_list')
    context = {'form':form}
    return render(request, 'schedule/create.html',context)

def edit(request, pk):
    schedule=Schedule.objects.get(id=pk)
    form = ScheduleForm(instance=schedule)
    if request.method=='POST':
        form = ScheduleForm(request.POST, instance=schedule)
        if form.is_valid():
           form.save()
           messages.success(request,'Data update successfull',extra_tags='success')
           return redirect('/schedule_list')
    context={'form':form}
    return render(request, 'schedule/create.html',context)

def delete(request,pk):
    schedule=Schedule.objects.get(id=pk)
    schedule.delete()
    messages.success(request,'Data delete successfull',extra_tags='success')
    return redirect('/schedule_list')


def stopage(request,pk):
    stopages=ScheduleStopage.objects.filter(schedule=pk).all()
    contex = {'stopages':stopages,'schedule':pk}
    return render(request, 'schedule/stopage.html',contex)

def add_stopage(request,pk):
    form=ScheduleStopageForm()
    stopage=Stopage.objects.all()
    if request.method=='POST':
        schedule=Schedule.objects.get(id=pk)
        reach_time=request.POST.get('reach_time')
        leave_time=request.POST.get('leave_time')
        form = ScheduleStopageForm(request.POST)
        if form.is_valid():
           for row in request.POST.getlist('stopage'):
               stopage=Stopage.objects.get(id=row)
               ScheduleStopage.objects.create(schedule=schedule, stopage=stopage, reach_time=reach_time, leave_time=leave_time)
               #schedule=form.save()
           messages.success(request,'Data store successfull',extra_tags='success')
           return redirect(reverse('schedule.stopage', args=[pk]))
    context={'form':form,'schedule':pk, 'stopage':stopage}
    return render(request, 'schedule/add_stopage.html',context)



def delete_stopage(request,pk):
    schedule=ScheduleStopage.objects.get(id=pk)
    schedule.delete()
    messages.success(request,'Data delete successfull',extra_tags='success')
    return redirect(reverse('schedule.stopage', args=[schedule.schedule.id]))


def member(request,pk):
    members=ScheduleMember.objects.filter(schedule=pk).all()
    contex = {'members':members,'schedule':pk}
    return render(request, 'schedule/member.html',contex)

def add_member(request,pk):
    form=ScheduleMemberForm()
    if request.method=='POST':
        schedule=Schedule.objects.get(id=pk)
        #if form.is_valid():
        if request.POST.getlist('user'):
            for row in request.POST.getlist('user'):
                print(row)
                if row:
                    print(row)
                    user=User.objects.get(id=row)
                    ScheduleMember.objects.create(schedule=schedule, user=user)
            messages.success(request,'Data store successfull',extra_tags='success')
            return redirect(reverse('schedule.member', args=[pk]))
        messages.success(request,'Please select a member',extra_tags='error')
        return redirect(reverse('schedule.add_member', args=[pk]))
    context={'form':form,'schedule':pk}
    return render(request, 'schedule/add_member.html',context)


def delete_member(request,pk):
    schedule=ScheduleMember.objects.get(id=pk)
    schedule.delete()
    messages.success(request,'Data delete successfull',extra_tags='success')
    return redirect(reverse('schedule.member', args=[schedule.schedule.id]))