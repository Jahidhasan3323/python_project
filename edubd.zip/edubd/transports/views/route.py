from django.shortcuts import render
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import reverse
from ..models import Route
from ..form import RouteForm
from django.contrib import messages 
# Create your views here.


def index(request):
    routes=Route.objects.all().order_by('-id')
    contex = {'routes':routes}
    return render(request, 'route/index.html',contex)

def create(request):
    form = RouteForm()
    if request.method=='POST':
        route=request.POST
        form = RouteForm(request.POST) 
        if form.is_valid():
           route=form.save()
           messages.success(request,'Data store successfull',extra_tags='success')
           return redirect('/route_list')
    context = {'form':form}
    return render(request, 'route/create.html',context)

def edit(request, pk):
    route=Route.objects.get(id=pk)
    form = RouteForm(instance=route)
    if request.method=='POST':
        form = RouteForm(request.POST, instance=route)
        if form.is_valid():
           form.save()
           messages.success(request,'Data update successfull',extra_tags='success')
           return redirect('/route_list')
    context={'form':form}
    return render(request, 'route/create.html',context)

def delete(request,pk):
    route=Route.objects.get(id=pk)
    route.delete()
    messages.success(request,'Data delete successfull',extra_tags='success')
    return redirect('/route_list')