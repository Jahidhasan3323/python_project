from django.shortcuts import render
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import reverse
from ..models import Stopage
from ..form import StopageForm
from django.contrib import messages 
# Create your views here.


def index(request):
    stopages=Stopage.objects.all().order_by('-id')
    contex = {'stopages':stopages}
    return render(request, 'stopage/index.html',contex)

def create(request):
    form = StopageForm()
    if request.method=='POST':
        stopage=request.POST
        form = StopageForm(request.POST) 
        if form.is_valid():
           stopage=form.save()
           messages.success(request,'Data store successfull',extra_tags='success')
           return redirect('/stopage_list')
    context = {'form':form}
    return render(request, 'stopage/create.html',context)

def edit(request, pk):
    stopage=Stopage.objects.get(id=pk)
    form = StopageForm(instance=stopage)
    if request.method=='POST':
        form = StopageForm(request.POST, instance=stopage)
        if form.is_valid():
           form.save()
           messages.success(request,'Data update successfull',extra_tags='success')
           return redirect('/stopage_list')
    context={'form':form}
    return render(request, 'stopage/create.html',context)

def delete(request,pk):
    stopage=Stopage.objects.get(id=pk)
    stopage.delete()
    messages.success(request,'Data delete successfull',extra_tags='success')
    return redirect('/stopage_list')