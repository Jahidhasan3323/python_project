from django.shortcuts import render
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import reverse
from ..models import Fare
from ..form import FareForm
from django.contrib import messages 
# Create your views here.


def index(request):
    fares=Fare.objects.all().order_by('-id')
    contex = {'fares':fares}
    return render(request, 'fare/index.html',contex)

def create(request):
    form = FareForm()
    if request.method=='POST':
        fare=request.POST
        form = FareForm(request.POST) 
        if form.is_valid():
           fare=form.save()
           messages.success(request,'Data store successfull',extra_tags='success')
           return redirect('/fare_list')
    context = {'form':form}
    return render(request, 'fare/create.html',context)

def edit(request, pk):
    fare=Fare.objects.get(id=pk)
    form = FareForm(instance=fare)
    if request.method=='POST':
        form = FareForm(request.POST, instance=fare)
        if form.is_valid():
           form.save()
           messages.success(request,'Data update successfull',extra_tags='success')
           return redirect('/fare_list')
    context={'form':form}
    return render(request, 'fare/create.html',context)

def delete(request,pk):
    fare=Fare.objects.get(id=pk)
    fare.delete()
    messages.success(request,'Data delete successfull',extra_tags='success')
    return redirect('/fare_list')


