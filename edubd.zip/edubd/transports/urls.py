from django.urls import path
from .views import driver, vehicle, stopage, route, schedule, fare

urlpatterns = [
    #driver
    path('driver_list',driver.index, name="driver.list"),
    path('driver/create',driver.create, name="driver.create"),
    path('driver/edit/<int:pk>',driver.edit, name="driver.edit"),
    path('driver/delete/<int:pk>',driver.delete, name="driver.delete"),
    
    
    #vehicle
    path('vehicle_list',vehicle.index, name="vehicle.list"),
    path('vehicle/create',vehicle.create, name="vehicle.create"),
    path('vehicle/edit/<int:pk>',vehicle.edit, name="vehicle.edit"),
    path('vehicle/delete/<int:pk>',vehicle.delete, name="vehicle.delete"),
    path('vehicle/driver/<int:pk>',vehicle.driver, name="vehicle.driver"),
    path('vehicle/add_driver/<int:pk>',vehicle.add_driver, name="vehicle.add_driver"),
    path('vehicle/driver_delete/<int:vehicle>/<int:driver>',vehicle.driver_delete, name="vehicle.driver_delete"),
    path('get_driver',vehicle.get_driver, name="get_driver"),

    #stopage
    path('stopage_list',stopage.index, name="stopage.list"),
    path('stopage/create',stopage.create, name="stopage.create"),
    path('stopage/edit/<int:pk>',stopage.edit, name="stopage.edit"),
    path('stopage/delete/<int:pk>',stopage.delete, name="stopage.delete"),
    
    
    #route
    path('route_list',route.index, name="route.list"),
    path('route/create',route.create, name="route.create"),
    path('route/edit/<int:pk>',route.edit, name="route.edit"),
    path('route/delete/<int:pk>',route.delete, name="route.delete"),
    
    
    #schedule
    path('schedule_list',schedule.index, name="schedule.list"),
    path('schedule/create',schedule.create, name="schedule.create"),
    path('schedule/edit/<int:pk>',schedule.edit, name="schedule.edit"),
    path('schedule/delete/<int:pk>',schedule.delete, name="schedule.delete"),
    path('schedule/stopage/<int:pk>',schedule.stopage, name="schedule.stopage"),
    path('schedule/add_stopage/<int:pk>',schedule.add_stopage, name="schedule.add_stopage"),
    path('schedule/delete_stopage/<int:pk>',schedule.delete_stopage, name="schedule.delete_stopage"),
    #member
    path('schedule/member/<int:pk>',schedule.member, name="schedule.member"),
    path('schedule/add_member/<int:pk>',schedule.add_member, name="schedule.add_member"),
    path('schedule/delete_member/<int:pk>',schedule.delete_member, name="schedule.delete_member"),

    #fare
    path('fare_list',fare.index, name="fare.list"),
    path('fare/create',fare.create, name="fare.create"),
    path('fare/edit/<int:pk>',fare.edit, name="fare.edit"),
    path('fare/delete/<int:pk>',fare.delete, name="fare.delete"),
]