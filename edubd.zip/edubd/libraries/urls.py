from django.urls import path
from . import views

urlpatterns = [
    path('author_list',views.author, name="author.list"),
    path('author/create',views.author_create, name="author.create"),
    path('author/edit/<int:pk>',views.author_edit, name="author.edit"),
    path('author/delete/<int:pk>',views.author_delete, name="author.delete"),
    
    #publisher
    path('publisher_list',views.publisher, name="publisher.list"),
    path('publisher/create',views.publisher_create, name="publisher.create"),
    path('publisher/edit/<int:pk>',views.publisher_edit, name="publisher.edit"),
    path('publisher/delete/<int:pk>',views.publisher_delete, name="publisher.delete"),
    
    #subject
    path('subject_list',views.subject, name="subject.list"),
    path('subject/create',views.subject_create, name="subject.create"),
    path('subject/edit/<int:pk>',views.subject_edit, name="subject.edit"),
    path('subject/delete/<int:pk>',views.subject_delete, name="subject.delete"),

    #book_language
    path('book_language_list',views.book_language, name="book_language.list"),
    path('book_language/create',views.book_language_create, name="book_language.create"),
    path('book_language/edit/<int:pk>',views.book_language_edit, name="book_language.edit"),
    path('book_language/delete/<int:pk>',views.book_language_delete, name="book_language.delete"),

    #rack
    path('rack_list',views.rack, name="rack.list"),
    path('rack/create',views.rack_create, name="rack.create"),
    path('rack/edit/<int:pk>',views.rack_edit, name="rack.edit"),
    path('rack/delete/<int:pk>',views.rack_delete, name="rack.delete"),

    #book
    path('book_list',views.book, name="book.list"),
    path('book/view/<int:pk>',views.book_view, name="book.view"),
    path('book/create',views.book_create, name="book.create"),
    path('book/edit/<int:pk>',views.book_edit, name="book.edit"),
    path('book/delete/<int:pk>',views.book_delete, name="book.delete"),
    
    
    #ebook
    path('ebook_list',views.ebook, name="ebook.list"),
    path('ebook/view/<int:pk>',views.ebook_view, name="ebook.view"),
    path('ebook/create',views.ebook_create, name="ebook.create"),
    path('ebook/edit/<int:pk>',views.ebook_edit, name="ebook.edit"),
    path('ebook/delete/<int:pk>',views.ebook_delete, name="ebook.delete"),


    #book_issue
    path('book_issue_list',views.book_issue, name="book_issue.list"),
    path('book_return_list',views.book_return, name="book_return.list"),
    path('book_issue/view/<int:pk>',views.book_issue_view, name="book_issue.view"),
    path('book_issue/create/<int:pk>',views.book_issue_create, name="book_issue.create"),
    path('book_issue/edit/<int:pk>',views.book_issue_edit, name="book_issue.edit"),
    path('book_issue/delete/<int:pk>',views.book_issue_delete, name="book_issue.delete"),
    path('make_return/<int:pk>',views.make_return, name="make_return"),
    
]