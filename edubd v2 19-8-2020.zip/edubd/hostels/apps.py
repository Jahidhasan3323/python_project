from django.apps import AppConfig


class HostelsConfig(AppConfig):
    name = 'hostels'
