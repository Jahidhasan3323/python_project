from django.apps import AppConfig


class LibrariesConfig(AppConfig):
    name = 'libraries'
