from django.apps import AppConfig


class TransportsConfig(AppConfig):
    name = 'transports'
